var x = 3;
        window.console.log(x);

        var y;
        y = 5;

        var z;
        window.console.log("the value of z is " + z);
        z = x + y;

        window.console.log("the value of z is " + z);
        window.console.log("the type of z is: " + typeof(z));

        z = x + " " + y;
        window.console.log("the value of z is " + z);
        window.console.log("the type of z is " + typeof(z));

        var greeting = "Hello";
        var firstname = "John";
        var message = greeting + " " + firstname;

        window.console.log("the value of message is: " + message);
        window.console.log("the type of message is: " + typeof(message));

        var check = (x == 5);
        window.console.log("the value of check is: " + check);
        window.console.log("the type of check is: " + typeof(check));

        var myArray = [1, 2, 3];
        window.console.log(myArray);
        window.console.log(typeof(myArray));