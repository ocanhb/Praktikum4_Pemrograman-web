var myPhone = new Object();
        myPhone.make = "Samsung";
        myPhone.model = "Galaxy S4";
        myPhone.warranty = 12;
        myPhone.color = "black";

        window.console.log(myPhone);

        myPhone.warranty = 0;

        window.console.log(myPhone);