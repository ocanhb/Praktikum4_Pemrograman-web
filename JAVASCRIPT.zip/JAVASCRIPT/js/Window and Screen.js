var windowHeight = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
        var screenWidth = window.screen.width;
        var availableScreenHeight = window.screen.availHeight;

        for (var i = 1; i <= 4; i++) {
            var div = document.getElementById("div" + i);
            div.style.width = (window.innerWidth / 4 - 10) + 'px';
            div.style.height = (window.innerHeight - 10) + 'px';
        }