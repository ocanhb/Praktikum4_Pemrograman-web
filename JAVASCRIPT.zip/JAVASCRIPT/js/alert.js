window.alert("Welcome to JavaScript!");
