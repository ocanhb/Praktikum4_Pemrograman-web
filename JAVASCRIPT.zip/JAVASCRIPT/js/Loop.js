// Loop for pertama (menaik dari 0 hingga 4)
        for (i = 0; i < 5; i++) {
            document.getElementById("myParagraph").innerHTML += "<br />" + i;
        }

        // Loop for kedua (menurun dari 7 hingga 1, ditampilkan hasil kuadratnya)
        for (i = 7; i > 0; i--) {
            document.getElementById("myParagraph").innerHTML += "<br />" + Math.pow(i, 2);
        }

        // Loop for untuk daftar belanja
        var shoppingList = ["bread", "milk", "eggs"];
        for (i = 0; i < shoppingList.length; i++) {
            document.getElementById("myParagraph").innerHTML += "<br />" + shoppingList[i];
        }

        // Simulasi pembelian menggunakan while loop
        var balance = 1000;
        var itemsBought = 0;

        while (balance > 0) {
            var itemPrice = Math.floor(Math.random() * 100);

            if (itemPrice <= balance) {
                itemsBought += 1;
                balance -= itemPrice;

                document.getElementById("balance").innerHTML += 
                    "<p>Purchase amount: $" + itemPrice + 
                    ". New Balance: $" + balance + ".</p>";
            }
        }

        document.getElementById("balance").innerHTML += "<p>You bought: " + itemsBought + " items.</p>";