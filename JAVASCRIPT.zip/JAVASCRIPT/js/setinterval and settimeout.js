var counter = document.getElementById("counter");
        var x = 0;

        var myCounter = setInterval(function () {
            x++;
            counter.innerHTML = x;
        }, 1000);

        var delayedWelcomeMessage = setTimeout(function () {
            window.alert("Welcome to our page");
        }, 3000);