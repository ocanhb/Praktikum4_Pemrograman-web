 document.getElementById("button1").onclick = function() {
            document.getElementById("facebook").style.width = '200px';
            document.getElementById("facebook").style.backgroundColor = 'rgba(26, 203, 135, 0.1)';
        };