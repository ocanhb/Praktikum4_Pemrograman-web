document.getElementById("button1").onclick = function() {
            document.getElementById("facebook").innerHTML = "<p>Facebook.</p>";
        }
        
        document.getElementById("button2").ondblclick = function() {
            document.getElementById("apple").innerHTML = "<ul><li>Audi</li><li>BMW</li><li>Mercedes</li></ul>";
        }