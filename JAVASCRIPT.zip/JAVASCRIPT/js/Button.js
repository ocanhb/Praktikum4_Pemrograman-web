document.getElementById("button2").onclick = function() {
    alert("You have just clicked me!");
};