// window.alert("Welcome to our page!");

var acceptCookies = window.confirm("Please confirm you accept cookies");
if (acceptCookies) {
    window.alert("You confirmed you accept cookies.");
} else {
    window.alert("You do not accept cookies.");
}

var visitor = prompt("Please enter your name.");
window.alert("Hi " + visitor.toUpperCase() + 
    ", we wish you a nice experience on our page! Don't forget to like us on Facebook!");